package com.tss.springcore.basics.controller;

import com.tss.springcore.basics.model.Computer;
import com.tss.springcore.basics.service.ComputerService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/app")
public class ComputerController {

    private final ComputerService computerServiceImpl;

    public ComputerController(ComputerService computerServiceImpl) {
        this.computerServiceImpl = computerServiceImpl;
    }

    @GetMapping("/computers")
    public Computer getComputer() {
        System.out.println(computerServiceImpl.getComputer());
        return computerServiceImpl.getComputer();
    }
}
